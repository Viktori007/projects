from Win import Win

if __name__ == "__main__":
    win = Win()
    win.main_cycle()

